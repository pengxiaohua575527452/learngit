<template>
  <!-- 首页 -->
  <div class="home container">
    <!-- 股价 -->
    <home-shares></home-shares>
    <!-- 业绩 -->
    <home-achievement></home-achievement>
    <!-- 新闻 -->
    <home-news></home-news>
    <!-- 活动 -->
    <home-activity></home-activity>
  </div>
</template>

<script type="text/ecmascript-6">
// alert('home.vue : ' + this.$i18.locale)
  import NewsList from '../../components/newsList/newsList'
  import HomeShares from './homeShares/homeShares'
  import HomeAchievement from './homeAchievement/homeAchievement'
  import HomeNews from './homeNews/homeNews'
  import HomeActivity from './homeActivity/homeActivity'
  import initSetLanguage from '../../configs/js/initSetLanguage.js';

  export default {
    name: 'home',
    components: {NewsList, HomeShares, HomeAchievement, HomeNews, HomeActivity},
    created:function(){
      var vm = this
      alert('开始调用 initSetLanguage 函数')
      initSetLanguage(vm)
      alert('initSetlanguage 函数调用完成，vm.$i18n.locale  == '+vm.$i18n.locale)
    }
  };
</script>

<style lang="less" type="text/less">
  .home {
    & .panel {
      border-bottom: 1px #EAEAEA solid;
    }
  }
</style>
